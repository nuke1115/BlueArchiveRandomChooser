DataBase 수정 관련은 DataBase에 내용을 추가하는법.txt 와 예시 파일.txt를 확인하세요
앱 파일들은 반드시 BlueArchiveRandomChooser 폴더 안에 위치해야합니다
======
사용,코드 수정,제배포,상업적 이용 전부 상관 없는데,
제배포, 상업적 이용시에는 원 제작자 표기와, 저한테 말해주시기만 하면 해도 됩니다
방송에서 사용하는건 말 굳이 안해도 됩니다
======
DataBase파일들을 수정할떄는 visualstudio 나 visualstudiocode나 notepad++을 이용하는걸 추천드립니다
======
혹시 문제가 발생하거나, 물어보고싶은게 있을떄는

@lysrhythmgamer - X (구 트위터)
노란딱지#7701 - Discord

로 연락해주시면 답변해드리겠습니다.